package org.example;

import org.example.logic.*;

import java.awt.*;
import java.util.ArrayList;

public class GameLogic {
    private Ball ball;
    private ArrayList<Enemy> enemies;
    private ArrayList<Wall> walls;
    private final int ENEMY_STEPS = 5;
    private final int BALL_STEPS = 20;

    public GameLogic() {
        this.ball = null;
        this.enemies = new ArrayList<>();
        this.walls = new ArrayList<>();
    }

    public void initialize() {
        ball = new Ball(20, 20, "bomb_green.jpg");

        Enemy enemy1 = new Enemy(350, 350, "bomb.jpg", 100);
        Enemy enemy2 = new Enemy(150, 250, "bomb.jpg", 100);
        enemies.add(enemy1);
        enemies.add(enemy2);

        Wall wall1 = new Wall(250, 30, 250, 130, Color.BLACK);
        Wall wall2 = new Wall(100, 50, 150, 50, Color.BLACK);
        walls.add(wall1);
        walls.add(wall2);
    }

    public void update() {
        updateEnemies();
        checkCollisions();
    }

    private void updateEnemies() {
        for (Enemy enemy : enemies) {
            int dx = ball.getCoord().x - enemy.getCoord().x;
            int dy = ball.getCoord().y - enemy.getCoord().y;

            Direction xDirection = (dx > 0) ? Direction.RIGHT : Direction.LEFT;
            Direction yDirection = (dy > 0) ? Direction.DOWN : Direction.UP;

            if (Math.abs(dx) > Math.abs(dy)) {
                if (!predictEnemyCollision(enemy, xDirection)) {
                    enemy.move(ENEMY_STEPS, xDirection);
                }
            } else {
                if (!predictEnemyCollision(enemy, yDirection)) {
                    enemy.move(ENEMY_STEPS, yDirection);
                }
            }
        }
    }

    private boolean predictEnemyCollision(Enemy enemy, Direction direction) {
        Rectangle enemyMoveRectangle = new Rectangle(enemy.getCoord().x, enemy.getCoord().y, enemy.getWidth(), enemy.getHeight());

        switch (direction) {
            case RIGHT:
                enemyMoveRectangle.translate(ENEMY_STEPS, 0);
                break;
            case LEFT:
                enemyMoveRectangle.translate(-ENEMY_STEPS, 0);
                break;
            case UP:
                enemyMoveRectangle.translate(0, -ENEMY_STEPS);
                break;
            case DOWN:
                enemyMoveRectangle.translate(0, ENEMY_STEPS);
                break;
        }

        for (Wall wall : walls) {
            if (enemyMoveRectangle.intersects(wall.getRectangle())) {
                return true;
            }
        }
        return false;
    }

    private void checkCollisions() {
        for (Wall wall : walls) {
            if (ball.isCollided(wall.getRectangle())) {
                wall.inactivate();
            }
        }

        for (Enemy enemy : enemies) {
            if (ball.isCollided(enemy.getRectangle())) {
                gameOver();
                return;
            }
        }
    }

    private void gameOver() {
        System.out.println("Game Over");
        System.exit(0);
    }

    public boolean predictPlayerCollision(Direction direction) {
        Rectangle moveRectangle = new Rectangle(ball.getX(), ball.getY(), ball.getWidth(), ball.getHeight());

        switch (direction) {
            case RIGHT:
                moveRectangle.translate(BALL_STEPS, 0);
                break;
            case LEFT:
                moveRectangle.translate(-BALL_STEPS, 0);
                break;
            case UP:
                moveRectangle.translate(0, -BALL_STEPS);
                break;
            case DOWN:
                moveRectangle.translate(0, BALL_STEPS);
                break;
        }

        for (Wall wall : walls) {
            if (moveRectangle.intersects(wall.getRectangle())) {
                return true;
            }
        }

        for (Enemy enemy : enemies) {
            if (moveRectangle.intersects(enemy.getRectangle())) {
                return true;
            }
        }

        return false;
    }

    public Ball getBall() {
        return ball;
    }

    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }

    public ArrayList<Wall> getWalls() {
        return walls;
    }

    public void movePlayer(Direction direction) {
        ball.move(BALL_STEPS, direction);
    }

    public boolean predictCollision(Direction direction) {
        return predictPlayerCollision(direction) || predictEnemyCollision(direction);
    }

    private boolean predictEnemyCollision(Direction direction) {
        Rectangle moveRectangle = new Rectangle(ball.getX(), ball.getY(), ball.getWidth(), ball.getHeight());

        switch (direction) {
            case RIGHT:
                moveRectangle.translate(BALL_STEPS, 0);
                break;
            case LEFT:
                moveRectangle.translate(-BALL_STEPS, 0);
                break;
            case UP:
                moveRectangle.translate(0, -BALL_STEPS);
                break;
            case DOWN:
                moveRectangle.translate(0, BALL_STEPS);
                break;
        }

        for (Wall wall : walls) {
            if (moveRectangle.intersects(wall.getRectangle())) {
                return true;
            }
        }

        for (Enemy enemy : enemies) {
            if (moveRectangle.intersects(enemy.getRectangle())) {
                return true;
            }
        }

        return false;
    }
}
