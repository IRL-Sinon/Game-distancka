# game-for-education-2
Založ projekt v IDEE a naklonuj kód.
Projekt březen - duben 2024
